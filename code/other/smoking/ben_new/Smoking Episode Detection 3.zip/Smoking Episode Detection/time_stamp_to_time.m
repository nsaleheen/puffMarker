function t = time_stamp_to_time(s)

t = s - s(1);